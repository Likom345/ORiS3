<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8"><title>Корзина</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    </head>
    <body>
        <%@ include file="common/header.jspf" %>
        <main class="container">
            <h1>
                Корзина
            </h1>
            <c:if test="${not empty sessionScope.checkoutError}">
            <p class="error">
                <c:out value="${sessionScope.checkoutError}"/>
            </p>
            <c:remove var="checkoutError" scope="session"/></c:if><c:if test="${empty cartProducts}">
            <p>
                Корзина пуста.
            </p>
            </c:if><c:forEach var="p" items="${cartProducts}">
            <div class="cart-row">
                <div>
                    <strong><c:out value="${p.name}"/></strong>—<c:out value="${p.salePrice}"/>₽
                </div>
                <form method="post" action="${pageContext.request.contextPath}/cart">
                    <input type="hidden" name="id" value="${p.productId}"><input type="number" name="quantity" min="1" max="50" value="${cart[p.productId]}" required><button>Изменить</button><button name="action" value="remove" class="secondary">Удалить</button>
                </form>
            </div>
            </c:forEach><c:if test="${not empty cartProducts}"><c:choose><c:when test="${not empty sessionScope.user}">
            <form method="post" action="${pageContext.request.contextPath}/checkout">
                <label>Комментарий к заказу<textarea name="comment" maxlength="1000"></textarea></label><button>Оформить заказ</button>
            </form>
            </c:when><c:otherwise>
            <p>
                Для оформления заказа<a href="${pageContext.request.contextPath}/login">войдите в аккаунт</a>.
            </p>
            </c:otherwise></c:choose></c:if>
        </main>
    </body>
</html>
